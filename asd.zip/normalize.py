import json
import os
from datetime import datetime

FILE_PATH = 'verified_user_data.json'

# Fields to group under "general"
GENERAL_KEYS = {"first_name", "last_name", "birthday", "psid", "timestamp", "in_family"}

def normalize_verified_data():
    if not os.path.exists(FILE_PATH):
        print(f"❌ File not found: {FILE_PATH}")
        return

    with open(FILE_PATH, 'r') as f:
        data = json.load(f)

    updated = False

    for user_id, info in data.items():
        # Skip if already normalized
        if "general" in info:
            continue

        # Only normalize if it contains general fields
        if any(k in info for k in GENERAL_KEYS):
            general_info = {}
            other_info = {}

            for key, value in info.items():
                if key in GENERAL_KEYS:
                    if key == "birthday":
                        try:
                            # Normalize birthday to MM/DD/YYYY
                            parsed = datetime.strptime(value, "%m/%d/%Y")
                            value = parsed.strftime("%m/%d/%Y")
                        except ValueError:
                            try:
                                parsed = datetime.strptime(value, "%b %d, %Y")
                                value = parsed.strftime("%m/%d/%Y")
                            except ValueError:
                                print(f"⚠️ Could not parse birthday for {user_id}: {value}")
                    general_info[key] = value
                else:
                    other_info[key] = value

            data[user_id] = {
                "general": general_info,
                **other_info
            }
            updated = True

    if updated:
        with open(FILE_PATH, 'w') as f:
            json.dump(data, f, indent=2)
        print("✅ verified_user_data.json has been normalized.")
    else:
        print("ℹ️ No changes were needed. All data was already normalized.")

if __name__ == "__main__":
    normalize_verified_data()
